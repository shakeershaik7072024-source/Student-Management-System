# Student Management System (Core Java)

## Project overview
A beginner-friendly console application for managing student records. It lets a user add, view, search, and delete student details.

## Features
- Add a student with ID, name, course, and marks
- Display all saved student records
- Search for a student by ID
- Delete a student by ID
- Basic input validation and duplicate-ID checking

## Concepts used
- Java classes and objects
- Encapsulation
- ArrayList
- Loops and switch statements
- Methods
- Scanner for user input
- Conditional statements

## Requirements
- JDK 14 or later (the menu uses modern switch-arrow syntax)
- Any Java IDE, or a terminal with `javac` and `java`

## How to run
1. Save `StudentManagementSystem.java`.
2. Open a terminal in the same folder.
3. Compile:
   `javac StudentManagementSystem.java`
4. Run:
   `java StudentManagementSystem`

## Note
This learning project stores records in memory. Records are cleared when the program closes. It does not use a database.

## Suggested LinkedIn project description
Developed a console-based Student Management System using Core Java. Implemented add, view, search, and delete operations for student records using classes, objects, ArrayList, methods, loops, and input validation.
