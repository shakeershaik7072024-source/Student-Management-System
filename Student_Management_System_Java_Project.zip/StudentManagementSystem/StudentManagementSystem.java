import java.util.ArrayList;
import java.util.Scanner;

class Student {
    private int id;
    private String name;
    private String course;
    private double marks;

    public Student(int id, String name, String course, double marks) {
        this.id = id;
        this.name = name;
        this.course = course;
        this.marks = marks;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getCourse() { return course; }
    public double getMarks() { return marks; }

    public void display() {
        System.out.printf("%-8d %-20s %-15s %.2f%n", id, name, course, marks);
    }
}

public class StudentManagementSystem {
    private static final ArrayList<Student> students = new ArrayList<>();
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;

        do {
            System.out.println("\n===== STUDENT MANAGEMENT SYSTEM =====");
            System.out.println("1. Add student");
            System.out.println("2. View all students");
            System.out.println("3. Search student by ID");
            System.out.println("4. Delete student by ID");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            while (!sc.hasNextInt()) {
                System.out.print("Please enter a number (1-5): ");
                sc.next();
            }
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1 -> addStudent();
                case 2 -> viewStudents();
                case 3 -> searchStudent();
                case 4 -> deleteStudent();
                case 5 -> System.out.println("Thank you for using the system!");
                default -> System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);

        sc.close();
    }

    private static void addStudent() {
        System.out.print("Enter student ID: ");
        while (!sc.hasNextInt()) {
            System.out.print("Enter a valid numeric ID: ");
            sc.next();
        }
        int id = sc.nextInt();
        sc.nextLine();

        if (findStudent(id) != null) {
            System.out.println("A student with this ID already exists.");
            return;
        }

        System.out.print("Enter student name: ");
        String name = sc.nextLine().trim();
        System.out.print("Enter course (e.g., BCA): ");
        String course = sc.nextLine().trim();
        System.out.print("Enter marks: ");

        while (!sc.hasNextDouble()) {
            System.out.print("Enter valid marks: ");
            sc.next();
        }
        double marks = sc.nextDouble();
        sc.nextLine();

        if (name.isEmpty() || course.isEmpty() || marks < 0 || marks > 100) {
            System.out.println("Invalid details. Name/course cannot be empty and marks must be 0-100.");
            return;
        }

        students.add(new Student(id, name, course, marks));
        System.out.println("Student added successfully.");
    }

    private static void viewStudents() {
        if (students.isEmpty()) {
            System.out.println("No student records found.");
            return;
        }

        System.out.printf("%-8s %-20s %-15s %s%n", "ID", "NAME", "COURSE", "MARKS");
        System.out.println("------------------------------------------------------");
        for (Student student : students) {
            student.display();
        }
    }

    private static void searchStudent() {
        System.out.print("Enter student ID to search: ");
        while (!sc.hasNextInt()) {
            System.out.print("Enter a valid numeric ID: ");
            sc.next();
        }
        int id = sc.nextInt();
        sc.nextLine();

        Student student = findStudent(id);
        if (student == null) {
            System.out.println("Student not found.");
        } else {
            System.out.printf("%-8s %-20s %-15s %s%n", "ID", "NAME", "COURSE", "MARKS");
            student.display();
        }
    }

    private static void deleteStudent() {
        System.out.print("Enter student ID to delete: ");
        while (!sc.hasNextInt()) {
            System.out.print("Enter a valid numeric ID: ");
            sc.next();
        }
        int id = sc.nextInt();
        sc.nextLine();

        Student student = findStudent(id);
        if (student == null) {
            System.out.println("Student not found.");
        } else {
            students.remove(student);
            System.out.println("Student deleted successfully.");
        }
    }

    private static Student findStudent(int id) {
        for (Student student : students) {
            if (student.getId() == id) {
                return student;
            }
        }
        return null;
    }
}
